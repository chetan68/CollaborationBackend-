package com.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.UriComponentsBuilder;

import com.model.Blog;
import com.service.BlogService;

@Controller
public class BlogRestController {

	@Autowired
	private BlogService blogService;

	
	

	@RequestMapping(value = "/blogs/{id}", method = RequestMethod.GET)
	public ResponseEntity<Blog> getBlogById(@PathVariable(value = "id") int id) {
		Blog blog = blogService.get(id);
		if (blog == null)
			return new ResponseEntity<Blog>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Blog>(blog, HttpStatus.OK);
	}

	@RequestMapping(value = "/blogs", method = RequestMethod.POST)
	public ResponseEntity<Void> createBlog(@RequestBody Blog blog, UriComponentsBuilder build) {
		/*
		 * blog.setBlogDateTime(Calendar.YEAR+"/"+Calendar.MONTH+"/"+Calendar.
		 * DAY_OF_MONTH); blog.setBlogDateTime(Calendar.DATE);
		 * 
		 * Calendar cal = Calendar.getInstance(); cal.setTime(date);
		 * cal.add(Calendar.DATE, days); //minus number would decrement the days
		 * blog.set cal.getTime();
		 */
		blogService.save(blog);
		HttpHeaders headers = new HttpHeaders();
		URI urilocation = build.path("/blogs/").path(String.valueOf(blog.getBlogid())).build().toUri();
		headers.setLocation(urilocation);
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/blogs", method = RequestMethod.GET)
	public ResponseEntity<List<Blog>> getAllBlog() {

		System.out.println(blogService.getAllBlog());

		List<Blog> blog = blogService.getAllBlog();

		if (blog.isEmpty())
			return new ResponseEntity<List<Blog>>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Blog>>(blog, HttpStatus.OK);
	}

	@RequestMapping(value = "/blogs/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Blog> updateBlog(@PathVariable int id, @RequestBody Blog blog) {

		Blog updatedblog = blogService.updateBlog(blog);
		if (blog == null)
			return new ResponseEntity<Blog>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Blog>(updatedblog, HttpStatus.OK);

	}

	@RequestMapping(value = "/blogs/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteBlogById(@PathVariable int id) {
		System.out.println(id);
		boolean res = blogService.deleteBlogById(id);
		if (res == false)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
