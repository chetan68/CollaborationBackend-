package com.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.UriComponentsBuilder;

import com.model.Event;

import com.service.EventService;

@Controller
public class EventRestController {

	@Autowired
	private EventService eventService;

	

	

	@RequestMapping(value = "/events/{id}", method = RequestMethod.GET)
	public ResponseEntity<Event> geteventById(@PathVariable(value = "id") int id) {
		Event event = eventService.get(id);
		if (event == null)
			return new ResponseEntity<Event>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Event>(event, HttpStatus.OK);
	}

	@RequestMapping(value = "/events", method = RequestMethod.POST)
	public ResponseEntity<Void> createEvent(@RequestBody Event event, UriComponentsBuilder build) {
		eventService.save(event);
		HttpHeaders headers = new HttpHeaders();
		URI urilocation = build.path("/events/").path(String.valueOf(event.getEventid())).build().toUri();
		headers.setLocation(urilocation);
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/events", method = RequestMethod.GET)
	public ResponseEntity<List<Event>> getAllEvent() {

		System.out.println(eventService.getAllEvent());

		List<Event> event = eventService.getAllEvent();

		if (event.isEmpty())
			return new ResponseEntity<List<Event>>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<Event>>(event, HttpStatus.OK);
	}

	@RequestMapping(value = "/events/{id}", method = RequestMethod.PUT)
	public ResponseEntity<Event> updateEvent(@PathVariable int id, @RequestBody Event event) {

		Event updatedEvent = eventService.updateEvent(event);
		if (event == null)
			return new ResponseEntity<Event>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<Event>(updatedEvent, HttpStatus.OK);

	}

	@RequestMapping(value = "/events/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteEventById(@PathVariable int id) {
		System.out.println(id);
		boolean res = eventService.deleteEventById(id);
		if (res == false)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
