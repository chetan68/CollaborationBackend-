package com.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.UriComponentsBuilder;

import com.model.NewsBulletin;
import com.service.NewsBulletinService;

@Controller
public class NewsBulletinRestController {

	@Autowired
	private NewsBulletinService newsService;

	@RequestMapping(value = "/newss/{id}", method = RequestMethod.GET)
	public ResponseEntity<NewsBulletin> getNewsBulletinByID(@PathVariable(value = "id") int id) {
		NewsBulletin news = newsService.get(id);
		if (news == null)
			return new ResponseEntity<NewsBulletin>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<NewsBulletin>(news, HttpStatus.OK);

	}

	@RequestMapping(value = "/newss", method = RequestMethod.POST)
	public ResponseEntity<Void> createNewsBulletin(@RequestBody NewsBulletin news, UriComponentsBuilder build) {
		newsService.save(news);
		HttpHeaders headers = new HttpHeaders();
		URI urilocation = build.path("/newss/").path(String.valueOf(news.getNewsid())).build().toUri();
		headers.setLocation(urilocation);
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}

	@RequestMapping(value = "/newss", method = RequestMethod.GET)
	public ResponseEntity<List<NewsBulletin>> getAllNewsBulletin() {

		System.out.println(newsService.getAllNewsBulletin());

		List<NewsBulletin> news = newsService.getAllNewsBulletin();

		if (news.isEmpty())
			return new ResponseEntity<List<NewsBulletin>>(HttpStatus.NO_CONTENT);
		return new ResponseEntity<List<NewsBulletin>>(news, HttpStatus.OK);
	}

	@RequestMapping(value = "/newss/{id}", method = RequestMethod.PUT)
	public ResponseEntity<NewsBulletin> updateNewsBulletin(@PathVariable int id, @RequestBody NewsBulletin news) {

		NewsBulletin updatedNewsBulletin = newsService.updateNewsBulletin(news);
		if (news == null)
			return new ResponseEntity<NewsBulletin>(HttpStatus.NOT_FOUND);
		return new ResponseEntity<NewsBulletin>(updatedNewsBulletin, HttpStatus.OK);

	}

	@RequestMapping(value = "/newss/{id}", method = RequestMethod.DELETE)
	public ResponseEntity<Void> deleteNewsBulletinById(@PathVariable int id) {
		System.out.println(id);
		boolean res = newsService.deleteNewsBulletinById(id);
		if (res == false)
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		else
			return new ResponseEntity<Void>(HttpStatus.OK);
	}

}
