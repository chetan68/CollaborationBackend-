package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.BlogDAO;
import com.model.Blog;

@Service
public class BlogServiceImpl implements BlogService {

	@Autowired
	BlogDAO blogDAO;

	public boolean save(Blog blog) {

		return blogDAO.save(blog);
	}

	public Blog get(int blogid) {

		return blogDAO.get(blogid);
	}

	public Blog updateBlog(Blog blog) {
		return blogDAO.updateBlog(blog);
	}

	public boolean deleteBlogById(int blogid) {

		return blogDAO.deleteBlogById(blogid);
	}

	public List<Blog> getAllBlog() {

		return blogDAO.getAllBlog();
	}

	public boolean isUserExist(Blog blog) {
		return false;
	}

	

}
