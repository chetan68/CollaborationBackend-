package com.service;

import java.util.List;

import com.model.User;

public interface UserService {
	public boolean save(User user);

	public User get(int userid);

	public User updateUser(User users);

	public boolean deleteUserById(int userid);

	// List<User> findAllUsers();
	List<User> getAllUser();

	public boolean isUserExist(User users);

}
