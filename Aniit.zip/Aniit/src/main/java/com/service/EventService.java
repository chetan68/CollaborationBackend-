package com.service;

import java.util.List;

import com.model.Event;

public interface EventService {

	public boolean save(Event event);

	public Event get(int eventid);

	public Event updateEvent(Event event);

	public boolean deleteEventById(int eventid);

	List<Event> getAllEvent();

	public boolean isUserExist(Event event);

}
