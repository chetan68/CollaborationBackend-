package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.UserDAO;
import com.model.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserDAO userDAO;

	public boolean save(User user) {
		return userDAO.save(user);
	}

	public User get(int userid) {
		return userDAO.get(userid);
	}

	public User updateUser(User users) {

		return userDAO.updateUser(users);

	}

	public boolean deleteUserById(int userid) {
		return userDAO.deleteUserById(userid);
	}

	public boolean isUserExist(User users) {

		return false;
	}

	public List<User> getAllUser() {

		return userDAO.getAllUser();
	}

}
