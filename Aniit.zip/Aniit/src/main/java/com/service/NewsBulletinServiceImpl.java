package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.NewsBulletinDAO;
import com.model.NewsBulletin;

@Service
public class NewsBulletinServiceImpl implements NewsBulletinService {

	@Autowired
	NewsBulletinDAO newsDAO;

	public boolean save(NewsBulletin news) {
		// TODO Auto-generated method stub
		return newsDAO.save(news);
	}

	public NewsBulletin get(int newsid) {

		return newsDAO.get(newsid);
	}

	public NewsBulletin updateNewsBulletin(NewsBulletin news) {

		return newsDAO.updateNewsBulletin(news);
	}

	public boolean deleteNewsBulletinById(int newsid) {

		return newsDAO.deleteNewsBulletinById(newsid);
	}

	public List<NewsBulletin> getAllNewsBulletin() {
		return newsDAO.getAllNewsBulletin();
	}

	public boolean isUserExist(NewsBulletin news) {
		// TODO Auto-generated method stub
		return false;
	}

}
