package com.service;

import java.util.List;

import com.model.JobOpportunity;

public interface JobOpportunityService {

	public boolean save(JobOpportunity job);

	public JobOpportunity get(int jobid);

	public JobOpportunity updateJobOpportunity(JobOpportunity job);

	public boolean deleteJobOpportunityById(int jobid);

	List<JobOpportunity> getAllJobOpportunity();

	public boolean isUserExist(JobOpportunity job);

}
