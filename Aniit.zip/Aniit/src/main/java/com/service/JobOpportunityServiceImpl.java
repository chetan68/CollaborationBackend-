package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.JobOpportunityDAO;
import com.model.JobOpportunity;

@Service
public class JobOpportunityServiceImpl implements JobOpportunityService {

	@Autowired
	JobOpportunityDAO jobDAO;

	public boolean save(JobOpportunity job) {
		// TODO Auto-generated method stub
		return jobDAO.save(job);
	}

	public JobOpportunity get(int jobid) {
		// TODO Auto-generated method stub
		return jobDAO.get(jobid);
	}

	public JobOpportunity updateJobOpportunity(JobOpportunity job) {
		// TODO Auto-generated method stub
		return jobDAO.updateJobOpportunity(job);
	}

	public boolean deleteJobOpportunityById(int jobid) {
		// TODO Auto-generated method stub
		return jobDAO.deleteJobOpportunityById(jobid);
	}

	public List<JobOpportunity> getAllJobOpportunity() {
		// TODO Auto-generated method stub
		return jobDAO.getAllJobOpportunity();
	}

	public boolean isUserExist(JobOpportunity job) {
		// TODO Auto-generated method stub
		return false;
	}

}
