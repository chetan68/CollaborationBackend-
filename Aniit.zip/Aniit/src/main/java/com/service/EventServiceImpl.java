package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.EventDAO;
import com.model.Event;

@Service
public class EventServiceImpl implements EventService {

	@Autowired
	EventDAO eventDAO;

	public boolean save(Event event) {

		return eventDAO.save(event);
	}

	public Event get(int eventid) {
		return eventDAO.get(eventid);
	}

	public Event updateEvent(Event event) {

		return eventDAO.updateEvent(event);
	}

	public boolean deleteEventById(int eventid) {

		return eventDAO.deleteEventById(eventid);
	}

	public List<Event> getAllEvent() {

		return eventDAO.getAllEvent();
	}

	public boolean isUserExist(Event event) {

		return false;
	}

}
