package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Blog")
public class Blog {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Blogid;
	private String BlogTitle;
	private String BlogContent;
	private String BlogDateTime;
	private char BlogStatus; // A=Approved, R=Rejected, P=Pending
	private String BlogComments;
	private String userid;

	public int getBlogid() {
		return Blogid;
	}

	public void setBlogid(int blogid) {
		Blogid = blogid;
	}

	public String getBlogTitle() {
		return BlogTitle;
	}

	public void setBlogTitle(String blogTitle) {
		BlogTitle = blogTitle;
	}

	public String getBlogContent() {
		return BlogContent;
	}

	public void setBlogContent(String blogContent) {
		BlogContent = blogContent;
	}

	public String getBlogDateTime() {
		return BlogDateTime;
	}

	public void setBlogDateTime(String blogDateTime) {
		BlogDateTime = blogDateTime;
	}

	public char getBlogStatus() {
		return BlogStatus;
	}

	public void setBlogStatus(char blogStatus) {
		BlogStatus = blogStatus;
	}

	public String getBlogComments() {
		return BlogComments;
	}

	public void setBlogComments(String blogComments) {
		BlogComments = blogComments;
	}

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

}
