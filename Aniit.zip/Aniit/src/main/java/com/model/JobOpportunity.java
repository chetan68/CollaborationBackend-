package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "JobOpportunity ")
public class JobOpportunity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Jobid;

	private String JobField;

	private String JobDesc;

	private String Designation;

	private String Package;

	private String Posteddate;

	private String Expirydate;

	private int Userid;

	public int getJobid() {
		return Jobid;
	}

	public void setJobid(int jobid) {
		Jobid = jobid;
	}

	public String getJobField() {
		return JobField;
	}

	public void setJobField(String jobField) {
		JobField = jobField;
	}

	public String getJobDesc() {
		return JobDesc;
	}

	public void setJobDesc(String jobDesc) {
		JobDesc = jobDesc;
	}

	public String getDesignation() {
		return Designation;
	}

	public void setDesignation(String designation) {
		Designation = designation;
	}

	public String getPackage() {
		return Package;
	}

	public void setPackage(String package1) {
		Package = package1;
	}

	public String getPosteddate() {
		return Posteddate;
	}

	public void setPosteddate(String posteddate) {
		Posteddate = posteddate;
	}

	public String getExpirydate() {
		return Expirydate;
	}

	public void setExpirydate(String expirydate) {
		Expirydate = expirydate;
	}

	public int getUserid() {
		return Userid;
	}

	public void setUserid(int userid) {
		Userid = userid;
	}

}
