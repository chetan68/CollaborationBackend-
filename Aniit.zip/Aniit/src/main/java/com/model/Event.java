package com.model;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "EVENT")
public class Event {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Eventid;
	private String EventName;
	private Timestamp EventDate;
	private Timestamp EventTime;
	private String EventPhoto;
	private String EventDesc;
	private String EventPlace;

	public int getEventid() {
		return Eventid;
	}

	public void setEventid(int eventid) {
		Eventid = eventid;
	}

	public String getEventName() {
		return EventName;
	}

	public void setEventName(String eventName) {
		EventName = eventName;
	}

	public Timestamp getEventDate() {
		return EventDate;
	}

	public void setEventDate(Timestamp eventDate) {
		EventDate = eventDate;
	}

	public Timestamp getEventTime() {
		return EventTime;
	}

	public void setEventTime(Timestamp eventTime) {
		EventTime = eventTime;
	}

	public String getEventPhoto() {
		return EventPhoto;
	}

	public void setEventPhoto(String eventPhoto) {
		EventPhoto = eventPhoto;
	}

	public String getEventDesc() {
		return EventDesc;
	}

	public void setEventDesc(String eventDesc) {
		EventDesc = eventDesc;
	}

	public String getEventPlace() {
		return EventPlace;
	}

	public void setEventPlace(String eventPlace) {
		EventPlace = eventPlace;
	}

}
