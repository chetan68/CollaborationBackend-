package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "NewsBulletin")
public class NewsBulletin {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int Newsid;
	private String NewsTitle;
	private String NewsDesc;
	private String NewsDate;
	private int Userid;

	public int getNewsid() {
		return Newsid;
	}

	public void setNewsid(int newsid) {
		Newsid = newsid;
	}

	public String getNewsTitle() {
		return NewsTitle;
	}

	public void setNewsTitle(String newsTitle) {
		NewsTitle = newsTitle;
	}

	public String getNewsDesc() {
		return NewsDesc;
	}

	public void setNewsDesc(String newsDesc) {
		NewsDesc = newsDesc;
	}

	public String getNewsDate() {
		return NewsDate;
	}

	public void setNewsDate(String newsDate) {
		NewsDate = newsDate;
	}

	public int getUserid() {
		return Userid;
	}

	public void setUserid(int userid) {
		Userid = userid;
	}

}
