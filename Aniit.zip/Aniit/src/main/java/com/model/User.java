package com.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="USERS")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int Userid;
	private String FullName;
	private String UserName;
	private String DOB;
	private String Gender; // M or F
	private String Password;
	private String Address;
	private String Email;
	private String Mobile;
	private String Status; // active or inactive uPending and Rejected
							// respectively
	private String Reason;
	private int Roleid; // 1-Admin, 2-Employee, 3-student
	private char Is_online; // Y=Yes or N=NO

	/*
	 * public User() { }
	 * 
	 * public User(int Userid, String FullName, String UserName, String DOB,
	 * String Gender, String Password, String Address, String Email, String
	 * Mobile, String Status, String Reason, int Roleid, char Is_online) {
	 * this.Userid=Userid; this.FullName=FullName; this.UserName=UserName;
	 * this.DOB=DOB; this.Gender=Gender; this.Password=Password;
	 * this.Address=Address; this.Email=Email; this.Mobile=Mobile;
	 * this.Status=Status; this.Reason=Reason; this.Roleid=Roleid;
	 * this.Is_online=Is_online; }
	 */

	public int getUserid() {
		return Userid;
	}

	public void setUserid(int userid) {
		Userid = userid;
	}

	public String getDOB() {
		return DOB;
	}

	public void setDOB(String dOB) {
		DOB = dOB;
	}

	public String getGender() {
		return Gender;
	}

	public void setGender(String gender) {
		Gender = gender;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getMobile() {
		return Mobile;
	}

	public void setMobile(String mobile) {
		Mobile = mobile;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getReason() {
		return Reason;
	}

	public void setReason(String reason) {
		Reason = reason;
	}

	public int getRoleid() {
		return Roleid;
	}

	public void setRoleid(int roleid) {
		Roleid = roleid;
	}

	public char getIs_online() {
		return Is_online;
	}

	public void setIs_online(char is_online) {
		Is_online = is_online;
	}

	public String getFullName() {
		return FullName;
	}

	public void setFullName(String fullName) {
		FullName = fullName;
	}

	public String getUserName() {
		return UserName;
	}

	public void setUserName(String userName) {
		UserName = userName;
	}

}
