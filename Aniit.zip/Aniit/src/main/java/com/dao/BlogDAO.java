package com.dao;

import java.util.List;

import com.model.Blog;

public interface BlogDAO {

	public boolean save(Blog blog);

	public Blog get(int blogid);

	public Blog updateBlog(Blog blog);

	public boolean deleteBlogById(int blogid);

	List<Blog> getAllBlog();

	public boolean isUserExist(Blog blog);

}
