package com.dao;

import java.util.List;

import com.model.NewsBulletin;

public interface NewsBulletinDAO {

	public boolean save(NewsBulletin news);

	public NewsBulletin get(int newsid);

	public NewsBulletin updateNewsBulletin(NewsBulletin news);

	public boolean deleteNewsBulletinById(int newsid);

	List<NewsBulletin> getAllNewsBulletin();

	public boolean isUserExist(NewsBulletin news);

}
