package com.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.JobOpportunity;

@Repository
public class JobOpportunityDAOImpl implements JobOpportunityDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean save(JobOpportunity job) {
		Session session = sessionFactory.openSession();
		session.save(job);
		session.flush();
		session.close();
		return false;

	}

	public JobOpportunity get(int jobid) {
		Session session = sessionFactory.openSession();
		JobOpportunity job = (JobOpportunity) session.get(JobOpportunity.class, jobid);
		session.close();
		return job;

	}

	@Transactional
	public JobOpportunity updateJobOpportunity(JobOpportunity job) {
		Session session = sessionFactory.openSession();
		int id = job.getJobid();
		System.out.println("id of JobOpportunity is " + id);
		if (session.get(JobOpportunity.class, id) == null)
			return null;
		session.merge(job);
		JobOpportunity updatedJobOpportunity = (JobOpportunity) session.get(JobOpportunity.class, id);
		session.flush();
		session.close();
		return updatedJobOpportunity;
	}

	public boolean deleteJobOpportunityById(int jobid) {
		Session session = sessionFactory.openSession();
		boolean ans = false;
		JobOpportunity job = (JobOpportunity) session.get(JobOpportunity.class, jobid);
		System.out.println(jobid);
		if (job != null) {
			session.delete(job);
			session.flush();
			session.close();
			ans = true;
		} else {
			session.flush();
			session.close();
		}
		return ans;
	}

	public List<JobOpportunity> getAllJobOpportunity() {
		Session session = sessionFactory.openSession();
		Query query = session.createQuery("from JobOpportunity");
		List<JobOpportunity> job = query.list();
		session.close();
		return job;

	}

	public boolean isUserExist(JobOpportunity job) {
		// TODO Auto-generated method stub
		return false;
	}

}
