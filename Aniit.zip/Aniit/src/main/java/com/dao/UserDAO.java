package com.dao;

import java.util.List;

import com.model.User;

public interface UserDAO {

	public boolean save(User user);

	public User get(int userid);

	public User updateUser(User users);

	public boolean deleteUserById(int userid);

	List<User> getAllUser();

	public boolean isUserExist(User users);
}
