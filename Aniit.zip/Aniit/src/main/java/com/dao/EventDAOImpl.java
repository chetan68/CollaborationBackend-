package com.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Event;

@Repository
public class EventDAOImpl implements EventDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean save(Event event) {
		Session session = sessionFactory.openSession();
		session.save(event);
		session.flush();
		session.close();
		return false;

	}

	public Event get(int eventid) {
		Session session = sessionFactory.openSession();

		Event event = (Event) session.get(Event.class, eventid);

		session.close();

		return event;

	}

	@Transactional
	public Event updateEvent(Event event) {

		Session session = sessionFactory.openSession();
		int id = event.getEventid();
		System.out.println("id of EVENT is " + id);
		if (session.get(Event.class, id) == null)
			return null;

		session.merge(event);
		Event updatedEvent = (Event) session.get(Event.class, id);
		session.flush();
		session.close();
		return updatedEvent;
	}

	public boolean deleteEventById(int eventid) {
		Session session = sessionFactory.openSession();
		boolean ans = false;
		Event event = (Event) session.get(Event.class, eventid);
		System.out.println(eventid);
		if (event != null) {
			session.delete(event);
			session.flush();
			session.close();
			ans = true;
		} else {
			session.flush();
			session.close();
		}
		return ans;
	}

	public List<Event> getAllEvent() {

		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from Event");

		List<Event> event = query.list();

		session.close();

		return event;

	}

	public boolean isUserExist(Event event) {
		// TODO Auto-generated method stub
		return false;
	}

}
