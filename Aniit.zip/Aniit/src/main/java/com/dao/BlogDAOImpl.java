package com.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.Blog;

@Repository
public class BlogDAOImpl implements BlogDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public boolean save(Blog blog) {
		Session session = sessionFactory.openSession();
		session.save(blog);
		session.flush();
		session.close();
		return false;

	}

	public Blog get(int blogid) {
		Session session = sessionFactory.openSession();
		Blog blog = (Blog) session.get(Blog.class, blogid);
		session.close();
		return blog;
	}

	public Blog updateBlog(Blog blog) {
		Session session = sessionFactory.openSession();
		int id = blog.getBlogid();
		System.out.println("id of Blog is " + id);
		if (session.get(Blog.class, id) == null)
			return null;

		session.merge(blog);
		Blog updatedBlog = (Blog) session.get(Blog.class, id);
		session.flush();
		session.close();
		return updatedBlog;

	}

	public boolean deleteBlogById(int blogid) {
		Session session = sessionFactory.openSession();
		boolean ans = false;
		Blog blog = (Blog) session.get(Blog.class, blogid);
		System.out.println(blogid);
		if (blog != null) {
			session.delete(blog);
			session.flush();
			session.close();
			ans = true;
		} else {
			session.flush();
			session.close();
		}
		return ans;

	}

	public List<Blog> getAllBlog() {

		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from Blog");

		List<Blog> blog = query.list();

		session.close();

		return blog;

	}

	public boolean isUserExist(Blog blog) {

		return false;
	}

}
