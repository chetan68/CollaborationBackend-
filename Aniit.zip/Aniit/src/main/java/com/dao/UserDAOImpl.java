package com.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.User;

@Repository
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean save(User user) {
		Session session = sessionFactory.openSession();
		session.save(user);
		session.flush();
		session.close();
		return false;

	}

	public User get(int userid) {
		Session session = sessionFactory.openSession();

		User user = (User) session.get(User.class, userid);

		session.close();

		return user;

	}

	@Transactional
	public User updateUser(User user) {

		Session session = sessionFactory.openSession();
		int id=user.getUserid();
		System.out.println("id of USER is " + id);
		if (session.get(User.class, id) == null)
			return null;

		session.merge(user);
		User updatedUser = (User) session.get(User.class, id);
		session.flush();
		session.close();
		return updatedUser;
	}

	public boolean deleteUserById(int userid) {
		Session session = sessionFactory.openSession();
		boolean ans=false;
		User user = (User) session.get(User.class, userid);
		System.out.println(userid);
		if(user!=null)
		{
			session.delete(user);
			session.flush();
			session.close();
			ans=true;
		}
		else
		{
			session.flush();
			session.close();
		}
		return ans;
	}

	public boolean isUserExist(User users) {
		// TODO Auto-generated method stub
		return false;
	}

	public List<User> getAllUser() {

		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from User");

		List<User> user = query.list();

		session.close();

		return user;

	}

}
