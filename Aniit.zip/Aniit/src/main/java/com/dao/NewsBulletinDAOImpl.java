package com.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.model.NewsBulletin;
import com.model.User;

@Repository
public class NewsBulletinDAOImpl implements NewsBulletinDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public boolean save(NewsBulletin news) {
		Session session = sessionFactory.openSession();
		session.save(news);
		session.flush();
		session.close();

		return false;
	}

	public NewsBulletin get(int newsid) {

		Session session = sessionFactory.openSession();

		NewsBulletin news = (NewsBulletin) session.get(NewsBulletin.class, newsid);

		session.close();

		return news;
	}

	@Transactional
	public NewsBulletin updateNewsBulletin(NewsBulletin news) {

		Session session = sessionFactory.openSession();
		int id = news.getNewsid();
		System.out.println("id of NewsBulletin is " + id);
		if (session.get(NewsBulletin.class, id) == null)
			return null;

		session.merge(news);
		NewsBulletin updatedNewsBulletin = (NewsBulletin) session.get(NewsBulletin.class, id);
		session.flush();
		session.close();
		return updatedNewsBulletin;

	}

	public boolean deleteNewsBulletinById(int newsid) {

		Session session = sessionFactory.openSession();
		boolean ans = false;
		NewsBulletin news = (NewsBulletin) session.get(NewsBulletin.class, newsid);
		System.out.println(newsid);
		if (news != null) {
			session.delete(news);
			session.flush();
			session.close();
			ans = true;
		} else {
			session.flush();
			session.close();
		}
		return ans;

	}

	@Override
	public List<NewsBulletin> getAllNewsBulletin() {
		Session session = sessionFactory.openSession();

		Query query = session.createQuery("from NewsBulletin");

		List<NewsBulletin> news = query.list();

		session.close();

		return news;
	}

	@Override
	public boolean isUserExist(NewsBulletin news) {
		// TODO Auto-generated method stub
		return false;
	}

}
